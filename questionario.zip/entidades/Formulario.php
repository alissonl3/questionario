<?php
 
class Formulario{
    
    function Formulario(){}
    
    private $id;
    private $anoConclusao;
    private $ia1;
    private $ia2;
    private $ia3;
    private $ia4;
    private $ia5;
    private $ia6;
    private $ic1;
    private $ic2;
    private $ic3;
    private $ic4;
    private $ic5;
    private $ic6;
    private $ic7;
    private $ic8;
    private $ic9;
    private $ic10;
    private $id1;
    private $id2;
    private $id3;
    private $ip1;
    private $ip2;
    private $ip3;
    private $ip3a;
    private $ip3b;
    private $ip3c;
    private $ip3d;
    private $sugestao;
    private $semestre;
    private $idUsuario;
    private $status;
    
    
    
    
    public function getId() { return $this->id; } 
    public function setId($id) { $this->id = $id; }
    
    public function getAnoConclusao() { return $this->anoConclusao; } 
    public function setAnoConclusao($anoConclusao) { $this->anoConclusao = $anoConclusao; }
    
    public function getIA1() { return $this->ia1; } 
    public function setIA1($ia1) { $this->ia1 = $ia1; }
    
    public function getIA2() { return $this->ia2; } 
    public function setIA2($ia2) { $this->ia2 = $ia2; }
    
    public function getIA3() { return $this->ia3; } 
    public function setIA3($ia3) { $this->ia3 = $ia3; }
    
    public function getIA4() { return $this->ia4; } 
    public function setIA4($ia4) { $this->ia4 = $ia4; }
    
    public function getIA5() { return $this->ia5; } 
    public function setIA5($ia5) { $this->ia5 = $ia5; }
    
    public function getIA6() { return $this->ia6; } 
    public function setIA6($ia6) { $this->ia6 = $ia6; }
    
    public function getIC1() { return $this->ic1; } 
    public function setIC1($ic1) { $this->ic1 = $ic1; }
    
    public function getIC2() { return $this->ic2; } 
    public function setIC2($ic2) { $this->ic2 = $ic2; }
    
    public function getIC3() { return $this->ic3; } 
    public function setIC3($ic3) { $this->ic3 = $ic3; }
    
    public function getIC4() { return $this->ic4; } 
    public function setIC4($ic4) { $this->ic4 = $ic4; }
    
    public function getIC5() { return $this->ic5; } 
    public function setIC5($ic5) { $this->ic5 = $ic5; }
    
    public function getIC6() { return $this->ic6; } 
    public function setIC6($ic6) { $this->ic6 = $ic6; }
    
    public function getIC7() { return $this->ic7; } 
    public function setIC7($ic7) { $this->ic7 = $ic7; }
    
    public function getIC8() { return $this->ic8; } 
    public function setIC8($ic8) { $this->ic8 = $ic8; }
    
    public function getIC9() { return $this->ic9; } 
    public function setIC9($ic9) { $this->ic9 = $ic9; }
    
    public function getIC10() { return $this->ic10; } 
    public function setIC10($ic10) { $this->ic10 = $ic10; }
    
    public function getID1() { return $this->id1; } 
    public function setID1($id1) { $this->id1 = $id1; }
    
    public function getID2() { return $this->id2; } 
    public function setID2($id2) { $this->id2 = $id2; }
    
    public function getID3() { return $this->id3; } 
    public function setID3($id3) { $this->id3 = $id3; }
    
    public function getIP1() { return $this->ip1; } 
    public function setIP1($ip1) { $this->ip1 = $ip1; }
    
    public function getIP2() { return $this->ip2; } 
    public function setIP2($ip2) { $this->ip2 = $ip2; }
    
    public function getIP3() { return $this->ip3; } 
    public function setIP3($ip3) { $this->ip3 = $ip3; }
    
    public function getIP3A() { return $this->ip3a; } 
    public function setIP3A($ip3a) { $this->ip3a = $ip3a; }
    
    public function getIP3B() { return $this->ip3b; } 
    public function setIP3B($ip3b) { $this->ip3b = $ip3b; }
    
    public function getIP3C() { return $this->ip3c; } 
    public function setIP3C($ip3c) { $this->ip3c = $ip3c; }
    
    public function getIP3D() { return $this->ip3d; } 
    public function setIP3D($ip3d) { $this->ip3d = $ip3d; }
    
    public function getSugestao() { return $this->sugestao; } 
    public function setSugestao($sugestao) { $this->sugestao = $sugestao; }
    
    public function getSemestre() { return $this->semestre; } 
    public function setSemestre($semestre) { $this->semestre = $semestre; }
    
    public function getIdUsuario() { return $this->idUsuario; } 
    public function setIdUsuario($idUsuario) { $this->idUsuario = $idUsuario; }
    
    public function getStatus() { return $this->status; } 
    public function setStatus($status) { $this->status = $status; }
    
    
    
    
    
    
    
    
    
    

}

